/*******************************************************************************
**
** -----------------------------------------------------------------------------
** File Name    : ISOUDS_DyDfDaID_HAL.c
**
** Description  : Dynamically Define Data Identifier Service
**
** -----------------------------------------------------------------------------
**
*******************************************************************************/

/**************************************** Inclusion files *********************/
#include "ISOUDS_DyDfDaID.h"
#include "string.h"
#include "ISOUDS_DyDfDaIDCfg.h"
#include "ISOUDS_DyDfDaID_HAL.h"

#if (ISOUDS_APP_CONFIG == ISOUDS_SERVER)
/********************** Declaration of local symbol and constants *************/

/********************************* Declaration of local macros ****************/

/********************************* Declaration of local types *****************/

/******************************* Declaration of local variables ***************/

/******************************* Declaration of local constants ***************/

/****************************** Declaration of exported variables *************/

/****************************** Declaration of exported constants *************/

/*******************************************************************************
**                                      FUNCTIONS                              *
*******************************************************************************/

/**************************** Internal functions declarations *****************/

/******************************** Function definitions ************************/


#endif
